#ifndef TYPE_DEFINES_H
#define TYPE_DEFINES_H

// Typedefines
typedef unsigned char INT8U;
typedef unsigned short int INT16U;
typedef unsigned int INT32U;

typedef char INT8;
typedef short int INT16;
typedef int INT32;

#endif
